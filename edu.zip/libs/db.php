<?php

session_start();

$conn= new mysqli('localhost','root','','edu_result');


?>